package com.example.match_preview_api

data class MatchPreviewResponse(
    val preview: String
)


