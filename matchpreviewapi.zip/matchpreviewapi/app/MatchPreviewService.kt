import android.telecom.Call

// MatchPreviewService.kt
interface MatchPreviewService {
    @POST("generate-preview")
    fun getMatchPreview(@Body request: MatchPreviewRequest): Call<MatchPreviewResponse>
}

data class MatchPreviewRequest(
    val team1: String,
    val team2: String,
    val form1: String,
    val form2: String,
    val keyPlayers: String
)

data class MatchPreviewResponse(
    val preview: String
)
